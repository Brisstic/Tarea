import express from 'express';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import autoRoute from "./routes/auth.js";
import usersRoute from "./routes/users.js";
import hotelsRoute from "./routes/hotels.js";
import roomsRoute from "./routes/rooms.js";



dotenv.config()
const app = express();
const connect = async () =>{
    try {
        await mongoose.connect(process.env.MONGO);
        console.log("Conectados a MONGODB");
    } catch (error){
        throw error;
    }
}
mongoose.connection.on('connected',()=>{
    console.log("MongoDB Conectado!!!");
})
mongoose.connection.on('disconnected',()=>{
    console.log("MongoDB Desconectado!!!");
})

//middleWARE
app.use("/api/auth", autoRoute);
app.use("/api/users", usersRoute);
app.use("/api/hotels", hetelsRoute);
app.use("/api/rooms", roomsRoute);



app.listen (8800, ()=>{
    connect()
    console.log('Conectado al backend!!!jjj') 
})

app.get("/reservas",(req, res)=>{
    res.send(200, "Hola todo ok");
})
